import './App.css';
import BasicExample from './components/EmployeeFinalLink';


function App() {
  return (
    <div className="App">
      <>
      <BasicExample/>
      </>
    </div>
  );
}

export default App;

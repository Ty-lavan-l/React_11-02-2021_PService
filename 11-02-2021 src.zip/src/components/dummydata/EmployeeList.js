import React, { Component } from "react";
import myjson from "./data.json";
import "./Employee.css";

export default class EmployeeList extends Component {
  render() {
    return (
 
      <div className="table_main">
          <h2>Test Yantra Development Unit-Employee Details</h2>
          <table className="table table-hover">
            <thead>
              <tr>
                <th/><th/><th/><th/><th/>
                <th> <pre>   Employee ID</pre></th>
                <th> <pre>  Full Name </pre></th>
                <th>Gender</th>
                <th>Contact Number</th>
                <th>Alternate Number</th>
                <th><pre>  Emergency Number</pre></th>
                <th><pre> Emergency Number2</pre></th>
                <th><pre>          Officil Mail ID</pre></th>
                <th>Personel Mail ID</th>
                <th>Year Of Passout</th>
                <th>Stream</th>
                <th>Higher Qualification</th>
                <th>Date Of Join</th>
                <th>Expirience</th>
                <th>Skill On Frondend</th>
                <th>Skill On Backend</th>
                <th>Permanent Address</th>
                <th>Temporary Address</th>
                <th>City</th>
                <th>State</th>
                <th>Pin code</th>

              </tr>
            </thead>
            <tbody>
              {myjson.map((emp) => (
                <tr key={emp.empid}>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>

                  <td>{emp.empid}</td>
                  <td>{emp.FullName}</td>
                  <td>{emp.Gender}</td>
                  <td>{emp.ContactNum}</td>
                  <td>{emp.AlternateNum}</td>
                  <td>{emp.EmergencyNum1}</td>
                  <td>{emp.EmergencyNum2}</td>
                  <td>{emp.Officilemail}</td>
                  <td>{emp.Personelemail}</td>
                  <td>{emp.Yearofpass}</td>
                  <td>{emp.Stream}</td>
                  <td>{emp.Higherqualify}</td>
                  <td>{emp.Dateofjoin}</td>
                  <td>{emp.Expirience}</td>
                  <td>{emp.Skillonfrondend}</td>
                  <td>{emp.Skillonbackend}</td>
                  <td>{emp.Permanentaddress}</td>
                  <td>{emp.Tempaddress}</td>
                  <td>{emp.City}</td>
                  <td>{emp.State}</td>
                  <td>{emp.Pincode}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
    );
  }
}

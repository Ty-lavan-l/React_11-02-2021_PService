import React, { useState } from "react";
import { useSpring, animated } from "react-spring";
import AdminLoginForm from "../formick/AdminFormick";
import PrimarySearchAppBar from "./Navbar";

function AdminLogin() {
  const [registrationFormStatus] = useState(false);
  const loginProps = useSpring({ 
    left: registrationFormStatus ? -500 : 0, // Login form sliding positions
  });

  return (
    <div>
      <PrimarySearchAppBar/>
    <div className="login-register-wrapper top">
      <div className="nav-buttons">
          <h1>Login</h1>
      </div>
      <div className="form-group">
        <animated.form action="" id="loginform" style={loginProps}>
          <LoginForm />
        </animated.form>
      </div>
    </div>
    </div>
  );
}

function LoginForm() {
  return (
    <React.Fragment>
     <AdminLoginForm/>
    </React.Fragment>
  );
}

export default AdminLogin;


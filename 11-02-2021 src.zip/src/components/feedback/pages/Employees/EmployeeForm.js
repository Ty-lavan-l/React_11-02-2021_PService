import React, { useState, useEffect } from 'react'
import { Grid, } from '@material-ui/core';
import Controls from "../../newcomponents/controls/Controls";
import { useForm, Form } from '../../newcomponents/useForm';
import * as employeeService from "../../services/employeeService";
import TextField from '@material-ui/core/TextField';



const initialFValues = {
    empid: '',
    fullName: '',
    mockdate: new Date(),
    mocktakenby: '',
    technology: '',
    therotical: '',
    praticle: '',
    overall: '',
    detailedfeedback:''
   
}

export default function EmployeeForm() {

    const validate = (fieldValues = values) => {
        let temp = { ...errors }
        if ('fullName' in fieldValues)
            temp.fullName = fieldValues.fullName ? "" : "Pleasr provide fullname."
        if ('empid' in fieldValues)
            temp.empid = (/[0-9]+/).test(fieldValues.empid) ? "" : "Employee-id is not valid."
        if ('therotical' in fieldValues)
            temp.therotical = fieldValues.therotical.length < 4 ? "" : "Should have proper rating."
        if ('overall' in fieldValues)
            temp.overall = fieldValues.overall.length !== 0 ? "" : "Please select overall rating."
        setErrors({
            ...temp
        })

        if (fieldValues === values)
            return Object.values(temp).every(x => x == "")
    }

    const {
        values,
        setValues,
        errors,
        setErrors,
        handleInputChange,
        resetForm
    } = useForm(initialFValues, true, validate);

    const handleSubmit = e => {
        e.preventDefault()
        if (validate()){
            employeeService.insertEmployee(values)
            resetForm()
        }
    }

    return (<div>
        <Form onSubmit={handleSubmit}>
            <Grid container justify="center">
                <Grid item xs={6}>
                    <h1>Enter Mock Details</h1>


                <Controls.Input
                        name="empid"
                        label="Employee ID"
                        value={values.empid}
                        onChange={handleInputChange}
                        error={errors.empid}
                    /> 
                    
                     <Controls.Input
                        name="fullName"
                        label="Full Name"
                        value={values.fullName || ''}
                        onChange={handleInputChange}
                        error={errors.fullName}
                    /> 
                    <form>
                    <TextField
                    id="date"
                    label="Mock Taken Date"
                    type="date"
                    defaultValue=""
                    InputLabelProps={{
                    shrink: true,
                     }}
                     />
                    </form>
                    
                    <Controls.Input
                        label="Mock taken By"
                        name="mocktakenby"
                        value={values.mocktakenby}
                        onChange={handleInputChange}
                        error={errors.mocktakenby}
                    />
                    <Controls.Input
                        label="Technology"
                        name="technology"
                        value={values.technology}
                        onChange={handleInputChange}
                        error={errors.technology}
                    />
                    <Controls.Input
                        label="Therotical rating (out of 100)"
                        name="therotical"
                        value={values.therotical}
                        onChange={handleInputChange}
                    />
                    
                     <Controls.Input
                        label="Praticle rating (out of 100)"
                        name="pratical"
                        value={values.pratical}
                        onChange={handleInputChange}
                    />
    
                    <Controls.Select
                        name="overall"
                        label="Overall Rating"
                        value={values.overall}
                        onChange={handleInputChange}
                        options={employeeService.getDepartmentCollection()}
                        error={errors.overall}
                    />
                    <Controls.Input
                        label="Detailed Feedback"
                        name="detailedfeedback"
                        value={values.detailedfeedback}
                        onChange={handleInputChange}
                        error={errors.detailedfeedback}
                    />
                                       <div> 
                    <button  style={{border:"solid" ,backgroundColor:" rgba(19,38,79,1)",color:"white", borderRadius:" 12px", padding: "10px"}}>Submit</button>
                    <button type="reset" onClick={resetForm}  style={{border:"solid" ,backgroundColor:" rgba(19,38,79,1)",color:"white", borderRadius:" 12px", padding: "6px"}}>Reset</button>
                    </div>
                </Grid>
            </Grid>
        </Form>
        </div>
    )
}
